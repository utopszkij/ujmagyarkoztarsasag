ITPSocialButtons Module for Joomla! 
==========================
( Version 2.6 )
- - -

ITPSocialButtons is a Joomla! module that display sharing buttons on the website.

[Documentation and FAQ] (http://itprism.com/help/35-social-buttons-documentation-faq)

[Download ITPSocialButtons module] (http://itprism.com/free-joomla-extensions/social-marketing-seo/multi-share-buttons)