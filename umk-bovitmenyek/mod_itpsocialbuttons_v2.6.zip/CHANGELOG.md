ITPSocialButtons Module Release Notes
==========================

###v2.6
* Typo

###v2.5
* Added a print button functionality.

###v2.4
* Improved

###v2.3
* Improved

###v2.2
* Fixed [issue #22] (https://github.com/ITPrism/ITPSocialButtons-Plugin/issues/22). Problems with module when Joomla caching is on.
* It was replaced the URL for link sharing from Google Bookmarks to Google Plus.

###v2.1
* Improved short URL functionality

###v2.0
* Added functionality to add "Share with friend" link. Now users can send a link to their friends by email.
* Improved

###v1.9
* Removed white space and fixed some css issues. Thanks Kurtis LoVerde.
* Added new URL shortener services - goo.gl and bitly.com.
* Fixed shortener services 
* Improved language

###v1.8
* Added new icons packs

###v1.7
* Replaced the Twitter URL with the new one

###v1.6
* Added new 9 packages of icons
* Added shortener URL services
* Added new options
* Added fields for custom icons
* Improved

###v1.5
* Added new styles - classy,drink
* Added options for managing displaying icons
* Improved