<?php
/**
* @module		VJ Database Tool
* @copyright	Copyright (C) 2015 vj-tools.com
* @license		GPL
*/
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
define('JPATH_BASE', dirname(__FILE__) );

jimport('joomla.application.component.controller'); 

function com_install() 
{
	return true;
}

?>