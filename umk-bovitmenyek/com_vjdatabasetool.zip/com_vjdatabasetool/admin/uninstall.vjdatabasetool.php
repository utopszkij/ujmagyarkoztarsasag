<?php
/**
* @module		VJ Database Tool
* @copyright	Copyright (C) 2015 vj-tools.com
* @license		GPL
*/
defined('_JEXEC') or die('Direct Access to this location is not allowed.'); 

function com_uninstall()
{
	global $installer;
	
	return true;
}

?>
