<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * 
 */
class pkghs_usersInstallerScript {

        /**
         * Before Install
         *
         * @param   string  $route  処理のタイプ (install|uninstall|discover_install)
         * @param   JAdapterInstance  $adapter  The object responsible for running this script
         *
         * @return  boolean  True on success
         */
        public function preflight($route, JAdapterInstance $adapter){
        	
        }
 
        /**
         * After Install
         *
         * @param   string  $route  Which action is happening (install|uninstall|discover_install)
         * @param   JAdapterInstance  $adapter  The object responsible for running this script
         *
         * @return  boolean  True on success
         */
        public function postflight($route, JAdapterInstance $adapter){
		}
 
        /**
         * Install
         *
         * @param   JAdapterInstance  $adapter  The object responsible for running this script
         *
         * @return  boolean  True on success
         */
        public function install(JAdapterInstance $adapter){
        	
        }
 
        /**
         * Update
         *
         * @param   JAdapterInstance  $adapter  The object responsible for running this script
         *
         * @return  boolean  True on success
         */
        public function update(JAdapterInstance $adapter){
        	
        }
 
        /**
         * Uninstall
         *
         * @param   JAdapterInstance  $adapter  The object responsible for running this script
         */
        public function uninstall(JAdapterInstance $adapter){
        	$db = JFactory::getDbo();
    			$query = $db->getQuery(true);
    			$query->select('extension_id,client_id');
    			$query->from('#__extensions');
    			$query->where('name='.$db->quote('com_hs_users').' OR name='.$db->quote('mod_hs_users').' OR name='.$db->quote('plg_user_hs_profile').' OR name='.$db->quote('lib_hs'));
    			
    			$db->setQuery($query);
    			
    			$r = $db->loadObjectList();
    			
    			if(empty($r)){
    				return;
    			}
    			
    			$ids = array();
    			foreach($r as $row){
    				$ids[] = (int)$row->extension_id;
    			}
    			
    			require_once JPATH_ADMINISTRATOR.'/components/com_installer/models/manage.php';	
    			$model = JModelLegacy::getInstance('Manage', 'InstallerModel');
    			
    			$model->remove($ids);
        }


}
