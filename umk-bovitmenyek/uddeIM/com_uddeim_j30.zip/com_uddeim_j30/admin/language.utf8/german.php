<?php
if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) )
	die( 'Restricted access' ); 
require_once( dirname( __FILE__ ).'/germanf.php' );
