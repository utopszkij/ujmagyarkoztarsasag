UPDATE `#__icagenda` SET version='2.1.2', releasedate='2013-03-21' WHERE id=1;
