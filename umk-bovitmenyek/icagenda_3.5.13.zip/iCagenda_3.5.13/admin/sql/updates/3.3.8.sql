UPDATE `#__icagenda` SET version='3.3.8', releasedate='2014-07-04' WHERE id=3;
