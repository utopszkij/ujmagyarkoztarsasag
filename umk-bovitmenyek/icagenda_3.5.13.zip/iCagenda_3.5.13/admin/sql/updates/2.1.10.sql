UPDATE `#__icagenda` SET version='2.1.10', releasedate='2013-05-07' WHERE id=1;
