UPDATE `#__icagenda` SET version='2.1.1', releasedate='2013-03-14' WHERE id=1;
