UPDATE `#__icagenda` SET version='3.5.0', releasedate='2015-02-25' WHERE id=3;
