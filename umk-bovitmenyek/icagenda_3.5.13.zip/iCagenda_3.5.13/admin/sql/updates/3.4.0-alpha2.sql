UPDATE `#__icagenda` SET version='3.4.0-alpha2', releasedate='2014-07-16' WHERE id=3;
