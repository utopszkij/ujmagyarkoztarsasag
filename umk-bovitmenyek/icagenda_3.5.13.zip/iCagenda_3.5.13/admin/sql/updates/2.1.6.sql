UPDATE `#__icagenda` SET version='2.1.6', releasedate='2013-04-12' WHERE id=1;
