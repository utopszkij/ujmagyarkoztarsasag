UPDATE `#__icagenda` SET version='2.1.2.2', releasedate='2013-03-27' WHERE id=1;
