UPDATE `#__icagenda` SET version='3.2.6', releasedate='2013-11-21' WHERE id=2;
