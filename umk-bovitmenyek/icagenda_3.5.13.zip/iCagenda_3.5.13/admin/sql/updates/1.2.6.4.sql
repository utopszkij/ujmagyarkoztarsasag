UPDATE `#__icagenda` SET version='1.2.6', releasedate='2012-10-15' WHERE id=1;


