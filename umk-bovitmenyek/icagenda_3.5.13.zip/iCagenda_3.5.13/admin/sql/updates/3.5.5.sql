UPDATE `#__icagenda` SET version='3.5.5', releasedate='2015-04-27' WHERE id=3;
