UPDATE `#__icagenda` SET version='3.1.8', releasedate='2013-08-30' WHERE id=2;
