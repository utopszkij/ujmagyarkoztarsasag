UPDATE `#__icagenda` SET version='3.4.0-alpha1', releasedate='2014-07-11' WHERE id=3;
