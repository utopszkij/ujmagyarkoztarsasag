UPDATE `#__icagenda` SET version='3.1.1', releasedate='2013-07-29' WHERE id=2;
