UPDATE `#__icagenda` SET version='3.2.5', releasedate='2013-11-11' WHERE id=2;
