UPDATE `#__icagenda` SET version='3.4.0', releasedate='2014-12-22' WHERE id=3;
