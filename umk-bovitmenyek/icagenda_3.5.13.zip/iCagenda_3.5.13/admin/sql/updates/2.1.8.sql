UPDATE `#__icagenda` SET version='2.1.8', releasedate='2013-04-30' WHERE id=1;
