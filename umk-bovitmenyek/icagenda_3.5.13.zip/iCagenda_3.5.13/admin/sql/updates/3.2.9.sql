UPDATE `#__icagenda` SET version='3.2.9', releasedate='2013-12-28' WHERE id=2;
