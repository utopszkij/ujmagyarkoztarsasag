UPDATE `#__icagenda` SET version='3.2.8', releasedate='2013-12-15' WHERE id=2;
