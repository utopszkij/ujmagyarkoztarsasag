UPDATE `#__icagenda` SET version='2.1.3', releasedate='2013-04-01' WHERE id=1;
