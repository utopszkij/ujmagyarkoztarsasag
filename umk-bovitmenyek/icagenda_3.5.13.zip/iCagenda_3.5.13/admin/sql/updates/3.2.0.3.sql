UPDATE `#__icagenda` SET version='3.2.0 RC3', releasedate='2013-09-26' WHERE id=2;
