UPDATE `#__icagenda` SET version='3.3.0', releasedate='2014-03-06' WHERE id=3;
