UPDATE `#__icagenda` SET version='1.3 beta3', releasedate='2012-12-16' WHERE id=1;
