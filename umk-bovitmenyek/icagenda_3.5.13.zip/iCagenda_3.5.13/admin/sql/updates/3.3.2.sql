UPDATE `#__icagenda` SET version='3.3.2', releasedate='2014-03-17' WHERE id=3;
