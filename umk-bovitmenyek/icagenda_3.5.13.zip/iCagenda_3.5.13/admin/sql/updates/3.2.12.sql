UPDATE `#__icagenda` SET version='3.2.12', releasedate='2014-01-08' WHERE id=2;
