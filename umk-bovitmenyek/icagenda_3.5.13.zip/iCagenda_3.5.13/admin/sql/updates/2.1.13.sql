UPDATE `#__icagenda` SET version='2.1.13', releasedate='2013-05-23' WHERE id=1;
