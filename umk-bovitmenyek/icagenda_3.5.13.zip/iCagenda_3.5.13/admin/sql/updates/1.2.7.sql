UPDATE `#__icagenda` SET version='1.2.7', releasedate='2012-10-18' WHERE id=1;


