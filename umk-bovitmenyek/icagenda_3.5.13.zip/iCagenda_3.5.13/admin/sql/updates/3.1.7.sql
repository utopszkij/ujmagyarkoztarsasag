UPDATE `#__icagenda` SET version='3.1.7', releasedate='2013-08-29' WHERE id=2;
