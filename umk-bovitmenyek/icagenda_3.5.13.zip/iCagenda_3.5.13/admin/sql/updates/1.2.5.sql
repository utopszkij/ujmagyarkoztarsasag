UPDATE `#__icagenda` SET version='1.2.5' WHERE id=1;


