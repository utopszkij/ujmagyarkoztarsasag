UPDATE `#__icagenda` SET version='1.3', releasedate='2012-10-19' WHERE id=1;
