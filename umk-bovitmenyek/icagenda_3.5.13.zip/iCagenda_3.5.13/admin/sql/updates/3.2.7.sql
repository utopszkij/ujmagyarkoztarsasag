UPDATE `#__icagenda` SET version='3.2.7', releasedate='2013-11-23' WHERE id=2;
