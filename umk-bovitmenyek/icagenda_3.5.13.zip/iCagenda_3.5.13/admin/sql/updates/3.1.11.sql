UPDATE `#__icagenda` SET version='3.1.11', releasedate='2013-09-13' WHERE id=2;
