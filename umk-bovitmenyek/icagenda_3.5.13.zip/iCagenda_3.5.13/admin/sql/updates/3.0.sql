INSERT INTO `#__icagenda` (id,version,releasedate) VALUES (2,'3.0','2013-06-04');
