UPDATE `#__icagenda` SET version='3.3.1', releasedate='2014-03-14' WHERE id=3;
