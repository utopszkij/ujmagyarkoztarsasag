UPDATE `#__icagenda` SET version='3.1.12', releasedate='2013-09-17' WHERE id=2;
