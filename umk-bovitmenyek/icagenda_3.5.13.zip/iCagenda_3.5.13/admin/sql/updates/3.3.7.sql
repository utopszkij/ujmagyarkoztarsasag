UPDATE `#__icagenda` SET version='3.3.7', releasedate='2014-05-29' WHERE id=3;
