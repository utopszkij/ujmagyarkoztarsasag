UPDATE `#__icagenda` SET version='2.1.12', releasedate='2013-05-21' WHERE id=1;
