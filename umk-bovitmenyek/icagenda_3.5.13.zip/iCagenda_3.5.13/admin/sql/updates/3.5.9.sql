UPDATE `#__icagenda` SET version='3.5.9', releasedate='2015-08-01' WHERE id=3;
