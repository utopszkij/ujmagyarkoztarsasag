UPDATE `#__icagenda` SET version='3.5.11', releasedate='2015-09-05' WHERE id=3;
