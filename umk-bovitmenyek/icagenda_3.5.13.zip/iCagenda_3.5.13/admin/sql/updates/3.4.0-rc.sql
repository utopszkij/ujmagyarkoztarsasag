UPDATE `#__icagenda` SET version='3.4.0-rc', releasedate='2014-12-14' WHERE id=3;
