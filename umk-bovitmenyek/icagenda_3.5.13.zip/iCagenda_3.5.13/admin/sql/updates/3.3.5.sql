UPDATE `#__icagenda` SET version='3.3.5', releasedate='2014-04-27' WHERE id=3;
