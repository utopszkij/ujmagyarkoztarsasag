UPDATE `#__icagenda` SET version='1.2.6 beta2', releasedate='2012-10-11' WHERE id=1;


