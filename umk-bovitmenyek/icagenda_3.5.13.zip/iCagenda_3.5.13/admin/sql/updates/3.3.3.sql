UPDATE `#__icagenda` SET version='3.3.3', releasedate='2014-04-20' WHERE id=3;
