UPDATE `#__icagenda` SET version='3.4.0-beta2', releasedate='2014-11-09' WHERE id=3;
