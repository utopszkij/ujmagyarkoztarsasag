UPDATE `#__icagenda` SET version='3.5.10', releasedate='2015-09-01' WHERE id=3;
