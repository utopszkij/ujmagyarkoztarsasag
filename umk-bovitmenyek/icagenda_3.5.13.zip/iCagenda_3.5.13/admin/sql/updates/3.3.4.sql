UPDATE `#__icagenda` SET version='3.3.4', releasedate='2014-04-25' WHERE id=3;
