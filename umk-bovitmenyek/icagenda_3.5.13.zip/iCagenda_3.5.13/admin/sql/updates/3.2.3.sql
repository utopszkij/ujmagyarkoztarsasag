UPDATE `#__icagenda` SET version='3.2.3', releasedate='2013-10-20' WHERE id=2;
