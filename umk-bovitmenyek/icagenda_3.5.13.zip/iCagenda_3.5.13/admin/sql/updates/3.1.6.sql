UPDATE `#__icagenda` SET version='3.1.6', releasedate='2013-08-20' WHERE id=2;
