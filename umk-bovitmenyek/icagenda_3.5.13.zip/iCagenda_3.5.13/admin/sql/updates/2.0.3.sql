UPDATE `#__icagenda` SET version='2.0.3', releasedate='2013-01-10' WHERE id=1;
