UPDATE `#__icagenda` SET version='3.5.12', releasedate='2015-10-12' WHERE id=3;
