UPDATE `#__icagenda` SET version='3.5.8', releasedate='2015-07-17' WHERE id=3;
