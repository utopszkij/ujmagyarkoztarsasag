UPDATE `#__icagenda` SET version='3.5.1', releasedate='2015-03-01' WHERE id=3;
