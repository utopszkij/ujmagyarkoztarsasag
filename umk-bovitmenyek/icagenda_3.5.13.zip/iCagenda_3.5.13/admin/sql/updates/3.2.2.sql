UPDATE `#__icagenda` SET version='3.2.2', releasedate='2013-10-10' WHERE id=2;
