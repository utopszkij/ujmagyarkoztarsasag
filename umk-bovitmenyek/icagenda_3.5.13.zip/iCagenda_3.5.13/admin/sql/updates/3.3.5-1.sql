UPDATE `#__icagenda` SET version='3.3.5-1', releasedate='2014-04-29' WHERE id=3;
