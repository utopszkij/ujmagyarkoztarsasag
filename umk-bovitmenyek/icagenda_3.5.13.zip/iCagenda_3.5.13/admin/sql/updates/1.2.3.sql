UPDATE `#__icagenda` SET version='1.2.3' WHERE id=1;
