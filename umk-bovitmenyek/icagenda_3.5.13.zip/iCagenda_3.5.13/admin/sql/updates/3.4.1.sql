UPDATE `#__icagenda` SET version='3.4.1', releasedate='2015-01-30' WHERE id=3;
