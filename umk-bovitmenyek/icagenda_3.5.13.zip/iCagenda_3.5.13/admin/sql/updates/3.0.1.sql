UPDATE `#__icagenda` SET version='3.0.1', releasedate='2013-07-04' WHERE id=2;
