UPDATE `#__icagenda` SET version='2.0.4', releasedate='2013-01-23' WHERE id=1;
