UPDATE `#__icagenda` SET version='2.0.0 RC', releasedate='2012-12-31' WHERE id=1;
