UPDATE `#__icagenda` SET version='3.5.4', releasedate='2015-04-24' WHERE id=3;
