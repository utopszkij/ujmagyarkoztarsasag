UPDATE `#__icagenda` SET version='3.5.3', releasedate='2015-03-25' WHERE id=3;
