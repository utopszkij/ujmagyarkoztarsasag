UPDATE `#__icagenda` SET version='2.1.5', releasedate='2013-04-10' WHERE id=1;
