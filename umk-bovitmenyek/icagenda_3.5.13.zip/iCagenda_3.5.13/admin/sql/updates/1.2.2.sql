UPDATE `#__icagenda` SET version='1.2.2' WHERE id=1;
DROP TABLE IF EXISTS `#__icagenda_registration`;
DROP TABLE IF EXISTS `#__icagenda_location`;
