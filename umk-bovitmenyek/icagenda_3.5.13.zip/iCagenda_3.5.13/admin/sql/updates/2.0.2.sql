UPDATE `#__icagenda` SET version='2.0.2 RC', releasedate='2013-01-04' WHERE id=1;
