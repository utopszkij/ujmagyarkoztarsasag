UPDATE `#__icagenda` SET version='2.1', releasedate='2013-03-11' WHERE id=1;
