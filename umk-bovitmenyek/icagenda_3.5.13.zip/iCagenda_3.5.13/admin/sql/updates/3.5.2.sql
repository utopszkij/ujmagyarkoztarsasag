UPDATE `#__icagenda` SET version='3.5.2', releasedate='2015-03-13' WHERE id=3;
