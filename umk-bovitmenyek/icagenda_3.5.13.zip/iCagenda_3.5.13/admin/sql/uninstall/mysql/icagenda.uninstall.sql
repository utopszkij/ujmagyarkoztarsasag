--
-- iCagenda: Uninstall Database `icagenda`
--

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__icagenda`;
DROP TABLE IF EXISTS `#__icagenda_category`;
DROP TABLE IF EXISTS `#__icagenda_events`;
DROP TABLE IF EXISTS `#__icagenda_registration`;
DROP TABLE IF EXISTS `#__icagenda_customfields`;
DROP TABLE IF EXISTS `#__icagenda_customfields_data`;
DROP TABLE IF EXISTS `#__icagenda_feature`;
DROP TABLE IF EXISTS `#__icagenda_feature_xref`;
DROP TABLE IF EXISTS `#__icagenda_location`;
