<?php
/**
 * @package	AcyMailing for Joomla!
 * @version	4.9.3
 * @author	acyba.com
 * @copyright	(C) 2009-2015 ACYBA S.A.R.L. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?><fieldset class="adminform">
	<legend><?php echo JText::_( 'LANGUAGES' ); ?></legend>
	<?php echo $this->languages->display('languages',$this->list->languages); ?>
</fieldset>
