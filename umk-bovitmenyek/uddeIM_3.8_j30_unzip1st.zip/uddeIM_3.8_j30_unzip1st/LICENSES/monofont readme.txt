The fonts contained in this archive are Freeware.
No payment is required for the use of these fonts.  They're free!
Commercial use?  Sure, but a donation or a product sample would be
appreciated.

$40 US is the usual amount per font for commercial use but any amount is
appreciated.

I make all the fonts (around 450 of them) on my web page and they're all free.
I offer Deluxe versions of some of my fonts for sale.  They contain several
weights and styles of each font.  http://www.larabiefonts.com/deluxe.html

The page is called Larabie Fonts

try:
http://www.larabiefonts.com or search for Larabie Fonts in a search Engine

I've provided the world with about 450 free fonts, if you'd like to make a donation
I'd be more than happy to accept it.

No donation is too small!  Music and artwork are good too.
If you have some CD's you're not listening to anymore, send 'em along!

Send anything at all to

Ray Larabie
61 Wesley Ave.
Port Credit
Ontario, CANADA
L5H 2M8

If you decide to send a cheque (that's how we spell it in Canada)
make it payable to Ray Larabie.  If you want to double check the address
have a look at the donation section on any of my webpages.

Canadian or US funds?  Any funds are fine with me.
Whatever's easy for you.

Double-check the following URL and learn about alternate forms or payment
such as gift certificates and credit card donations.
 http://www.larabiefonts.com/donation.html

Ray Larabie
lf@typodermic.com or check http://www.larabiefonts.com/email.html



Font installation in Windows: Unzip the font using a program such as Winzip then drag & drop the font into your font folder (usually c:\windows\fonts)
Font installation on a Mac: You must have STUFFIT EXPANDER 5.1.2 (or better)
to expand the archive.

-------------------------------
Larabie Fonts End-user license agreement software product from Larabie Fonts
---------------------------------------------------

SOFTWARE PRODUCT LICENSE

The SOFTWARE PRODUCT is protected by copyright laws and international copyright treaties,
as well as other intellectual property laws and treaties. The SOFTWARE PRODUCT is licensed,
not sold.

1. GRANT OF LICENSE. This document grants you the following rights:

- Installation and Use. You may install and use an unlimited number of copies of the
SOFTWARE PRODUCT.  You may copy and distribute unlimited copies of the SOFTWARE PRODUCT as you receive them, in any medium, provided that you publish on each copy an appropriate copyright notice. Keep intact all the notices that refer to this License. And give any other  recipients of the fonts a copy of this License along with the fonts.

2. DESCRIPTION OF OTHER RIGHTS AND LIMITATIONS. 

- You may modify your copy or copies of the fonts or any portion
of it, provided that you also meet all of these rules:

        a) Do not alter in any way alphamumerics(eq. a-z, 1-9) contained in the font. An exception is converting between formats, here is allowed the nominal distortion that occurs during conversion from second order to third order quadratic curves (TrueType to Postscript) and vice versa. 
       
        b) Extra characters may be added, here it is allowed to use curves from alphanumerics in fonts under same license. 
        
        c) It is allowed to modify and remove analpahbetics (punctuation, special characters, ligatures and symbols).

	d) The original font name must remain but can be augmented. (ie.  Blue Highway Cyrillic, Blue Highway ANSI, Blue Highway Fudge)
	
        e) Character mapping may be altered.
	
        f) If the kerning information is damaged or discarded please state that in the user notes or documentation.
	
        g) All modifications must be released under this license.

LIMITED WARRANTY
NO WARRANTIES. Larabie Fonts expressly disclaims any warranty for the SOFTWARE PRODUCT. The
SOFTWARE PRODUCT and any related documentation is provided "as is" without warranty of any
kind, either express or implied, including, without limitation, the implied warranties or
merchantability, fitness for a particular purpose, or noninfringement. The entire risk
arising out of use or performance of the SOFTWARE PRODUCT remains with you.

NO LIABILITY FOR CONSEQUENTIAL DAMAGES. In no event shall Larabie Fonts be liable for any
damages whatsoever (including, without limitation, damages for loss of business profits,
business interruption, loss of business information, or any other pecuniary loss) arising
out of the use of or inability to use this product, even if Larabie Fonts has been advised
of the possibility of such damages.

3. MISCELLANEOUS

Should you have any questions concerning this document, or if you desire to contact
Larabie Fonts for any reason, please contact lf@typodermic.com , or write: Ray Larabie,
61 Wesley Ave. Mississauga, ON Canada L5H 2M8