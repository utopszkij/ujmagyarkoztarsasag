Important:

Check the README folder and read the README before you install uddeIM!


There is also a comprehensive FAQ that explains most problems:
 - SQL error messages
 - problems with the character encoding
 - and lots of more...

