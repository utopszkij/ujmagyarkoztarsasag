====================================================================================================
WHAT ARE PREMIUM PLUGINS?
====================================================================================================

There are currently six plugins exclusively available for donators.

Public Frontend Plugin
    Enables Public Frontend functionality in uddeIM. With enabling the Public Frontend
    unregistered users can send registered users PMs.

RSS Feed Plugin
    This plugin publishes your inbox using a RSS feed. So you can display PMs in
    your favourite RSS reader or on your personalized iGoogle page.

Message Report Control Plugin
    When enabled users can report annoying messages to the admin. The admin can check
    these messages in the backend and take appropriate actions.

File Attachments Plugin
	This plugin enables file attachments, so users can send small files to each other.

Message Control Plugin (experimental)
    You can enable message monitoring for certain mailboxes. When a user of a monitored 
	mailbox writes a message the message is only delivered when the admin approves it.

Postbox Plugin (experimental)
	The Postbox Plugin combines inbox and outbox in a single postbox.


All plugins can be downloaded from my support web site: 
    http://www.slabihoud.de/software/

When you are interested in these plugins, please make a donation using the donate 
buttons in uddeIM or on my support site. Ensure that your email address is submitted 
by PayPal, so I can send you your personal username/password. With these user 
credentials you are able to download the files from my webpage.

I decided to make some feature "premium" since there are currently 200.000 downloads
but only a dozens of donators (incl. translators). So these plugins are a 
"Thank you" for their donations and help. The donations help to pay the webtraffic
even when they do only cover less then 10% of the costs currently. 
