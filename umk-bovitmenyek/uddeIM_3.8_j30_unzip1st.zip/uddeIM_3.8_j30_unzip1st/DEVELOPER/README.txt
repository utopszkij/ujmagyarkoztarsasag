
You will find the API documentation is the FAQ (see README folder).
