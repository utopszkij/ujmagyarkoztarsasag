ITPSocialButtons Plug-in for Joomla!
==========================
( Version 2.6 )
- - -

ITPSocialButtons is a Joomla! plugin that adds sharing buttons of the most popular social networks.

[Documentation and FAQ] (http://itprism.com/help/35-social-buttons-documentation-faq)

[Download ITP Social Buttons plugin] (http://itprism.com/free-joomla-extensions/social-marketing-seo/multi-share-buttons)