DROP TABLE IF EXISTS #__beallitasok;
