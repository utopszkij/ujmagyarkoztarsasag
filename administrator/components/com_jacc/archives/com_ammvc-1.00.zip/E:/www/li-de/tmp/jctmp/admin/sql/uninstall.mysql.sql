DROP TABLE IF EXISTS #__amcomponents;
DROP TABLE IF EXISTS #__ammvc_categories;
