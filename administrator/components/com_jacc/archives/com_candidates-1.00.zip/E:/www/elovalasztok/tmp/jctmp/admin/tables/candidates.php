<?php
/**
* @version		$Id:candidates.php  1 2013-10-30 15:39:43Z FT $
* @package		Candidates
* @subpackage 	Tables
* @copyright	Copyright (C) 2013, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TableCandidates class
*
* @package		Candidates
* @subpackage	Tables
*/
class TableCandidates extends JTable
{
	
   /** @var int id- Primary Key  **/
   public $id = null;

   /** @var varchar name  **/
   public $name = null;

   /** @var int organization  **/
   public $organization = null;

   /** @var varchar nick  **/
   public $nick = null;

   /** @var varchar email  **/
   public $email = null;

   /** @var text bibliography  **/
   public $bibliography = null;

   /** @var text program  **/
   public $program = null;

   /** @var int setback  **/
   public $setback = null;

   /** @var int preselection  **/
   public $preselection = null;




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__candidates', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{ 
		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{



		/** check for valid name */
		/**
		if (trim($this->name) == '') {
			$this->setError(JText::_('Your Candidates must contain a name.')); 
			return false;
		}
		**/		

		return true;
	}
}
