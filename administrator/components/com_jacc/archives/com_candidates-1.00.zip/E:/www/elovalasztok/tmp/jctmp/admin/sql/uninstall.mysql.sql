DROP TABLE IF EXISTS #__candidates;
