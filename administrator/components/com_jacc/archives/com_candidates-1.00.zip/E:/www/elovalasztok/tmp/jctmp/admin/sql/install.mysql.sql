CREATE TABLE IF NOT EXISTS `#__candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` int(11) NOT NULL,
  `nick` varchar(32) COLLATE utf8_hungarian_ci NOT NULL,
  `name` varchar(80) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(80) COLLATE utf8_hungarian_ci NOT NULL,
  `bibliography` text COLLATE utf8_hungarian_ci NOT NULL,
  `program` text COLLATE utf8_hungarian_ci NOT NULL,
  `setback` int(1) NOT NULL,
  `preselection` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB COLLATE=utf8_hungarian_ci;

