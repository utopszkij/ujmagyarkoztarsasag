DROP TABLE IF EXISTS #__messages;
