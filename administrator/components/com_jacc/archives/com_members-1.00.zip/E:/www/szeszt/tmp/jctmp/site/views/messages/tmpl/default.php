<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>"><h2><?php echo $this->params->get('page_title');  ?></h2></div>
<h3><?php echo $this->item->subject; ?></h3>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	
	<div>
		Subject: <?php echo $this->item->subject; ?>
	</div>
	<div>
		State: <?php echo $this->item->state; ?>
	</div>
	<div>
		Message_id: <?php echo $this->item->message_id; ?>
	</div>

</div>
