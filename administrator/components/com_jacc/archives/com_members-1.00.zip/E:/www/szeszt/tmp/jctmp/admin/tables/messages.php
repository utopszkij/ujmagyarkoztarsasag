<?php
/**
* @version		$Id:messages.php  1 2013-10-27 12:47:57Z FT $
* @package		Members
* @subpackage 	Tables
* @copyright	Copyright (C) 2013, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TableMessages class
*
* @package		Members
* @subpackage	Tables
*/
class TableMessages extends JTable
{
	
   /** @var int message_id- Primary Key  **/
   public $message_id = null;

   /** @var varchar subject  **/
   public $subject = null;

   /** @var tinyint state  **/
   public $state = null;

   /** @var int unsigned user_id_from  **/
   public $user_id_from = null;

   /** @var int unsigned user_id_to  **/
   public $user_id_to = null;

   /** @var tinyint unsigned folder_id  **/
   public $folder_id = null;

   /** @var datetime date_time  **/
   public $date_time = "0000-00-00 00:00:00";

   /** @var tinyint unsigned priority  **/
   public $priority = null;

   /** @var text message  **/
   public $message = null;




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__messages', 'message_id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{ 
		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{



		/** check for valid name */
		/**
		if (trim($this->subject) == '') {
			$this->setError(JText::_('Your Messages must contain a subject.')); 
			return false;
		}
		**/		

		return true;
	}
}
