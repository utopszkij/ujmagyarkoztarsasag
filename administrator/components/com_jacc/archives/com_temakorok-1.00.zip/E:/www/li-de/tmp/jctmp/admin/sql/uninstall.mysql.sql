DROP TABLE IF EXISTS #__temakorok;
