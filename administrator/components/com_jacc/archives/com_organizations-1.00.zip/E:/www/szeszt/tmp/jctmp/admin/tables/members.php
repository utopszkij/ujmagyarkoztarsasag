<?php
/**
* @version		$Id:members.php  1 2013-10-27 14:28:06Z FT $
* @package		Organizations
* @subpackage 	Tables
* @copyright	Copyright (C) 2013, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TableMembers class
*
* @package		Organizations
* @subpackage	Tables
*/
class TableMembers extends JTable
{
	
   /** @var int id- Primary Key  **/
   public $id = null;

   /** @var varchar name  **/
   public $name = null;

   /** @var int organization  **/
   public $organization = null;

   /** @var varchar nick  **/
   public $nick = null;

   /** @var varchar password  **/
   public $password = null;

   /** @var varchar email  **/
   public $email = null;

   /** @var varchar zip  **/
   public $zip = null;

   /** @var varchar city  **/
   public $city = null;

   /** @var varchar address  **/
   public $address = null;

   /** @var varchar floor  **/
   public $floor = null;

   /** @var varchar door  **/
   public $door = null;

   /** @var varchar hair  **/
   public $hair = null;

   /** @var varchar eye  **/
   public $eye = null;

   /** @var varchar shoe  **/
   public $shoe = null;

   /** @var int childrens  **/
   public $childrens = null;

   /** @var int brothers  **/
   public $brothers = null;

   /** @var varchar animals  **/
   public $animals = null;

   /** @var varchar weight  **/
   public $weight = null;

   /** @var varchar birth  **/
   public $birth = null;

   /** @var varchar checked  **/
   public $checked = null;

   /** @var int appliciant  **/
   public $appliciant = null;

   /** @var text biography  **/
   public $biography = null;

   /** @var text program  **/
   public $program = null;




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__members', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{ 
		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{



		/** check for valid name */
		/**
		if (trim($this->name) == '') {
			$this->setError(JText::_('Your Members must contain a name.')); 
			return false;
		}
		**/		

		return true;
	}
}
