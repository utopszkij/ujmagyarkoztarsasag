<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>"><h2><?php echo $this->params->get('page_title');  ?></h2></div>
<h3><?php echo $this->item->name; ?></h3>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	
	<div>
		Name: <?php echo $this->item->name; ?>
	</div>
	<div>
		Nick: <?php echo $this->item->nick; ?>
	</div>
	<div>
		Password: <?php echo $this->item->password; ?>
	</div>
	<div>
		Email: <?php echo $this->item->email; ?>
	</div>
	<div>
		Zip: <?php echo $this->item->zip; ?>
	</div>
	<div>
		City: <?php echo $this->item->city; ?>
	</div>
	<div>
		Address: <?php echo $this->item->address; ?>
	</div>
	<div>
		Floor: <?php echo $this->item->floor; ?>
	</div>
	<div>
		Door: <?php echo $this->item->door; ?>
	</div>
	<div>
		Hair: <?php echo $this->item->hair; ?>
	</div>
	<div>
		Eye: <?php echo $this->item->eye; ?>
	</div>
	<div>
		Shoe: <?php echo $this->item->shoe; ?>
	</div>
	<div>
		Animals: <?php echo $this->item->animals; ?>
	</div>
	<div>
		Weight: <?php echo $this->item->weight; ?>
	</div>
	<div>
		Birth: <?php echo $this->item->birth; ?>
	</div>
	<div>
		Checked: <?php echo $this->item->checked; ?>
	</div>
	<div>
		Id: <?php echo $this->item->id; ?>
	</div>

</div>
