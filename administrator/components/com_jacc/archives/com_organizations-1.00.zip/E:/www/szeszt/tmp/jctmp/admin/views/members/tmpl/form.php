<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

// Set toolbar items for the page
$edit		= JRequest::getVar('edit', true);
$text = !$edit ? JText::_( 'New' ) : JText::_( 'Edit' );
JToolBarHelper::title(   JText::_( 'Members' ).': <small><small>[ ' . $text.' ]</small></small>' );
JToolBarHelper::apply();
JToolBarHelper::save();
if (!$edit) {
	JToolBarHelper::cancel();
} else {
	// for existing items the button is renamed `close`
	JToolBarHelper::cancel( 'cancel', 'Close' );
}
?>

<script language="javascript" type="text/javascript">


Joomla.submitbutton = function(task)
{
	if (task == 'cancel' || document.formvalidator.isValid(document.id('adminForm'))) {
		Joomla.submitform(task, document.getElementById('adminForm'));
	}
}

</script>

	 	<form method="post" action="index.php" id="adminForm" name="adminForm">
	 	<div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-60  <?php endif; ?>span8 form-horizontal fltlft">
		  <fieldset class="adminform">
			<legend><?php echo JText::_( 'Details' ); ?></legend>
							
				<?php echo $this->form->getLabel('name'); ?>
				
				<?php echo $this->form->getInput('name');  ?>
					
				<?php echo $this->form->getLabel('organization'); ?>
				
				<?php echo $this->form->getInput('organization');  ?>
					
				<?php echo $this->form->getLabel('nick'); ?>
				
				<?php echo $this->form->getInput('nick');  ?>
					
				<?php echo $this->form->getLabel('password'); ?>
				
				<?php echo $this->form->getInput('password');  ?>
					
				<?php echo $this->form->getLabel('email'); ?>
				
				<?php echo $this->form->getInput('email');  ?>
					
				<?php echo $this->form->getLabel('zip'); ?>
				
				<?php echo $this->form->getInput('zip');  ?>
					
				<?php echo $this->form->getLabel('city'); ?>
				
				<?php echo $this->form->getInput('city');  ?>
					
				<?php echo $this->form->getLabel('address'); ?>
				
				<?php echo $this->form->getInput('address');  ?>
					
				<?php echo $this->form->getLabel('floor'); ?>
				
				<?php echo $this->form->getInput('floor');  ?>
					
				<?php echo $this->form->getLabel('door'); ?>
				
				<?php echo $this->form->getInput('door');  ?>
					
				<?php echo $this->form->getLabel('hair'); ?>
				
				<?php echo $this->form->getInput('hair');  ?>
					
				<?php echo $this->form->getLabel('eye'); ?>
				
				<?php echo $this->form->getInput('eye');  ?>
					
				<?php echo $this->form->getLabel('shoe'); ?>
				
				<?php echo $this->form->getInput('shoe');  ?>
					
				<?php echo $this->form->getLabel('childrens'); ?>
				
				<?php echo $this->form->getInput('childrens');  ?>
					
				<?php echo $this->form->getLabel('brothers'); ?>
				
				<?php echo $this->form->getInput('brothers');  ?>
					
				<?php echo $this->form->getLabel('animals'); ?>
				
				<?php echo $this->form->getInput('animals');  ?>
					
				<?php echo $this->form->getLabel('weight'); ?>
				
				<?php echo $this->form->getInput('weight');  ?>
					
				<?php echo $this->form->getLabel('birth'); ?>
				
				<?php echo $this->form->getInput('birth');  ?>
					
				<?php echo $this->form->getLabel('checked'); ?>
				
				<?php echo $this->form->getInput('checked');  ?>
					
				<?php echo $this->form->getLabel('appliciant'); ?>
				
				<?php echo $this->form->getInput('appliciant');  ?>

				<div class="clr"></div>
					
					
				<?php echo $this->form->getLabel('biography'); ?>
				
					
				<div class="clr"></div>
					
				<?php echo $this->form->getInput('biography');  ?>

				<div class="clr"></div>
					
					
				<?php echo $this->form->getLabel('program'); ?>
				
					
				<div class="clr"></div>
					
				<?php echo $this->form->getInput('program');  ?>
					
					
			
						
          </fieldset>                      
        </div>
        <div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-30  <?php endif; ?>span2 fltrgt">
			        

        </div>                   
		<input type="hidden" name="option" value="com_organizations" />
	    <input type="hidden" name="cid[]" value="<?php echo $this->item->id ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="view" value="members" />
		<?php echo JHTML::_( 'form.token' ); ?>
	</form>