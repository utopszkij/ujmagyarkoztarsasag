<?php
/**
* @version		$Id:polls.php  1 2013-11-02 06:30:46Z FT $
* @package		Polls
* @subpackage 	Tables
* @copyright	Copyright (C) 2013, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TablePolls class
*
* @package		Polls
* @subpackage	Tables
*/
class TablePolls extends JTable
{
	
   /** @var int id- Primary Key  **/
   public $id = null;

   /** @var varchar title  **/
   public $title = null;

   /** @var text description  **/
   public $description = null;

   /** @var int organization  **/
   public $organization = null;

   /** @var varchar status  **/
   public $status = null;

   /** @var date regist_start  **/
   public $regist_start = null;

   /** @var date regi_ststop  **/
   public $regi_ststop = null;

   /** @var date discusion_start  **/
   public $discusion_start = null;

   /** @var date discusion_stop  **/
   public $discusion_stop = null;

   /** @var date vote_start  **/
   public $vote_start = null;

   /** @var date vote_stop  **/
   public $vote_stop = null;




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__polls', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{ 
		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{



		/** check for valid name */
		/**
		if (trim($this->title) == '') {
			$this->setError(JText::_('Your Polls must contain a title.')); 
			return false;
		}
		**/		

		return true;
	}
}
