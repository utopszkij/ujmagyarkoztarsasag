CREATE TABLE IF NOT EXISTS `#__polls` (
  `id` int(11) unsigned NOT NULL,
  `organization` int(11) NOT NULL,
  `title` varchar(80) COLLATE utf8_hungarian_ci NOT NULL,
  `description` text COLLATE utf8_hungarian_ci NOT NULL,
  `status` varchar(32) COLLATE utf8_hungarian_ci NOT NULL,
  `regist_start` date NOT NULL,
  `regi_ststop` date NOT NULL,
  `discusion_start` date NOT NULL,
  `discusion_stop` date NOT NULL,
  `vote_start` date NOT NULL,
  `vote_stop` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB COLLATE=utf8_hungarian_ci;

