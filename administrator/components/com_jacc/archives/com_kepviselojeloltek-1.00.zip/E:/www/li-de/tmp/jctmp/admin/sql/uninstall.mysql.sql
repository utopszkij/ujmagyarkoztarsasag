DROP TABLE IF EXISTS #__kepviselojeloltek;
