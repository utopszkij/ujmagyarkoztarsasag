DROP TABLE IF EXISTS #__alternativak;
