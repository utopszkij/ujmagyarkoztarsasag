<?php
/**
* @version		$Id: default_controller.php 96 2011-08-11 06:59:32Z michel $
* @package		Example_users
* @subpackage 	Controllers
* @copyright	Copyright (C) 2013, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * Example_usersUsers Controller
 *
 * @package    Example_users
 * @subpackage Controllers
 */
class Example_usersControllerUsers extends Example_usersController
{
	/**
	 * Constructor
	 */
	protected $_viewname = 'users'; 
	 
	public function __construct($config = array ()) 
	{
		parent :: __construct($config);
		JRequest :: setVar('view', $this->_viewname);

	}
	

	
	
}// class
?>