<?php
/**
* @version		$Id:users.php  1 2013-10-17 05:56:30Z FT $
* @package		Example_users
* @subpackage 	Tables
* @copyright	Copyright (C) 2013, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TableUsers class
*
* @package		Example_users
* @subpackage	Tables
*/
class TableUsers extends JTable
{
	
   /** @var int id- Primary Key  **/
   public $id = null;

   /** @var varchar name  **/
   public $name = null;

   /** @var text params  **/
   public $params = null;

   /** @var varchar username  **/
   public $username = null;

   /** @var varchar email  **/
   public $email = null;

   /** @var varchar password  **/
   public $password = null;

   /** @var tinyint block  **/
   public $block = null;

   /** @var tinyint sendEmail  **/
   public $sendEmail = null;

   /** @var datetime registerDate  **/
   public $registerDate = "0000-00-00 00:00:00";

   /** @var datetime lastvisitDate  **/
   public $lastvisitDate = "0000-00-00 00:00:00";

   /** @var varchar activation  **/
   public $activation = null;

   /** @var datetime lastResetTime  **/
   public $lastResetTime = "0000-00-00 00:00:00";

   /** @var int resetCount  **/
   public $resetCount = null;




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__users', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{
		if ( isset( $array['params'] ) && is_array( $array['params'] ) )
        {
            $array['params'] = json_encode( $array['params'] );

        }		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{



		/** check for valid name */
		/**
		if (trim($this->name) == '') {
			$this->setError(JText::_('Your Users must contain a name.')); 
			return false;
		}
		**/		

		return true;
	}
}
