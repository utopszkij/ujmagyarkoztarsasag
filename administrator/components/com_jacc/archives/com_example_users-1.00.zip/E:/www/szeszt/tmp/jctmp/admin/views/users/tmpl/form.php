<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

// Set toolbar items for the page
$edit		= JRequest::getVar('edit', true);
$text = !$edit ? JText::_( 'New' ) : JText::_( 'Edit' );
JToolBarHelper::title(   JText::_( 'Users' ).': <small><small>[ ' . $text.' ]</small></small>' );
JToolBarHelper::apply();
JToolBarHelper::save();
if (!$edit) {
	JToolBarHelper::cancel();
} else {
	// for existing items the button is renamed `close`
	JToolBarHelper::cancel( 'cancel', 'Close' );
}
?>

<script language="javascript" type="text/javascript">


Joomla.submitbutton = function(task)
{
	if (task == 'cancel' || document.formvalidator.isValid(document.id('adminForm'))) {
		Joomla.submitform(task, document.getElementById('adminForm'));
	}
}

</script>

	 	<form method="post" action="index.php" id="adminForm" name="adminForm">
	 	<div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-60  <?php endif; ?>span8 form-horizontal fltlft">
		  <fieldset class="adminform">
			<legend><?php echo JText::_( 'Details' ); ?></legend>
							
				<?php echo $this->form->getLabel('name'); ?>
				
				<?php echo $this->form->getInput('name');  ?>
					
				<?php echo $this->form->getLabel('username'); ?>
				
				<?php echo $this->form->getInput('username');  ?>
					
				<?php echo $this->form->getLabel('email'); ?>
				
				<?php echo $this->form->getInput('email');  ?>
					
				<?php echo $this->form->getLabel('password'); ?>
				
				<?php echo $this->form->getInput('password');  ?>
					
				<?php echo $this->form->getLabel('block'); ?>
				
				<?php echo $this->form->getInput('block');  ?>
					
				<?php echo $this->form->getLabel('sendEmail'); ?>
				
				<?php echo $this->form->getInput('sendEmail');  ?>
					
				<?php echo $this->form->getLabel('registerDate'); ?>
				
				<?php echo $this->form->getInput('registerDate');  ?>
					
				<?php echo $this->form->getLabel('lastvisitDate'); ?>
				
				<?php echo $this->form->getInput('lastvisitDate');  ?>
					
				<?php echo $this->form->getLabel('activation'); ?>
				
				<?php echo $this->form->getInput('activation');  ?>
					
				<?php echo $this->form->getLabel('lastResetTime'); ?>
				
				<?php echo $this->form->getInput('lastResetTime');  ?>
					
				<?php echo $this->form->getLabel('resetCount'); ?>
				
				<?php echo $this->form->getInput('resetCount');  ?>
					
					
			
						
          </fieldset>                      
        </div>
        <div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-30  <?php endif; ?>span2 fltrgt">
			        
     		
			<fieldset class="adminform">
				<legend><?php echo JText::_( 'Advanced Parameters' ); ?></legend>
				<table>				
				<?php 
					$fieldSets = $this->form->getFieldsets('params');
					foreach($fieldSets  as $name =>$fieldset):  ?>				
				<?php foreach ($this->form->getFieldset($name) as $field) : ?>
					<?php if ($field->hidden):  ?>
						<?php echo $field->input;  ?>
					<?php else:  ?>
					<tr>
						<td class="paramlist_key" width="40%">
							<?php echo $field->label;  ?>
						</td>
						<td class="paramlist_value">
							<?php echo $field->input;  ?>
						</td>
					</tr>
				<?php endif;  ?>
				<?php endforeach;  ?>
			<?php endforeach;  ?>
			</table>			
			</fieldset>									


        </div>                   
		<input type="hidden" name="option" value="com_example_users" />
	    <input type="hidden" name="cid[]" value="<?php echo $this->item->id ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="view" value="users" />
		<?php echo JHTML::_( 'form.token' ); ?>
	</form>